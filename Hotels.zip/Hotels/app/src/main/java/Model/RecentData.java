package Model;

public class RecentData {
}
