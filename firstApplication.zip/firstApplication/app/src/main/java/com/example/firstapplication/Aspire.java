package com.example.firstapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Aspire extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aspire);
    }

    public void Aspireprice(View view) {
        Intent intent=new Intent(Aspire.this,AspirePrice.class);
        startActivity(intent);
    }
}