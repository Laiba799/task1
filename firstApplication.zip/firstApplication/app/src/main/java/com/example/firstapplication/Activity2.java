package com.example.firstapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.net.wifi.rtt.CivicLocationKeys;
import android.os.Bundle;
import android.view.View;

public class Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
    }

    public void City(View view) {
        Uri uri=Uri.parse("tel:983478437439847");
        Intent intent=new Intent(Activity2.this,City.class);
        startActivity(intent);
    }

    public void Aspire(View view) {
        Intent intent=new Intent(Activity2.this,Aspire.class);
        startActivity(intent);
    }

    public void Brv(View view) {
        Intent intent=new Intent(Activity2.this,Brv.class);
        startActivity(intent);
    }

    public void Civic(View view) {
        Intent intent=new Intent(Activity2.this,civic.class);
        startActivity(intent);
    }

    public void Accord(View view) {
        Intent intent=new Intent(Activity2.this,Accord.class);
        startActivity(intent);
    }
}