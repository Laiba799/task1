package com.example.firstapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Accord extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accord);
    }

    public void Accordprice(View view) {
        Intent intent=new Intent(Accord.this,AccordPrice.class);
        startActivity(intent);
    }
}